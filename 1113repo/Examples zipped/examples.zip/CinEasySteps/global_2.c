int num = 200 ;			/* Global variable accessible from any file. */




