/*     FILE: example.c     */

#include <stdio.h>

/* C-style comments can span several lines 
   ...where they are terminated by:
*/

int main( )
{
  printf("Here's a program\n");

  return 0;
}


/*    OUTPUT: example.c

	Here's a program

*/
